#include "video.h"

void CVideo::Load(char *fileName){}
void CVideo::Play(){}
void CVideo::Stop(){}
void CVideo::Close(){}

bool CVideo::IsPlaying()
{
	return false;
}

bool CVideo::IsPlayCompleted()
{
	return true;
}