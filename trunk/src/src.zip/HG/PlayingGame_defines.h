#ifndef PLAYING_GAME__DEFINES__H__INCLUDED__
#define PLAYING_GAME__DEFINES__H__INCLUDED__

#include "Config.h"



	// hcenter-top aligned
	#define CASH_ATTACK_WIN_MONEY_X		(m_dispX >> 1)
	#define CASH_ATTACK_WIN_MONEY_Y		(m_dispY >> 1)
	
	#define SPEEDOMETER_CENTER_X (m_dispX - 35)
	#define SPEEDOMETER_CENTER_Y (m_dispY - 32)
	
	#define INTERFACE_KMPH_MPH_POS_X	(SPEEDOMETER_CENTER_X - 31)
	#define INTERFACE_KMPH_MPH_POS_Y	(SPEEDOMETER_CENTER_Y + 20)
	
	#define INTERFACE_NITRO_USED_POS_X	(SPEEDOMETER_CENTER_X - 10)
	#define INTERFACE_NITRO_USED_POS_Y	(SPEEDOMETER_CENTER_Y - 38)

	#define SPEED_X			(m_dispX - 92)
	#define SPEED_Y			(m_dispY - 17)

#ifdef TOUCH_INGAME_BUTTON_MENU
	#define INTERFACE_RANK_X 		(m_dispX - 30)
#else
	#define INTERFACE_RANK_X 		30
#endif
	#define INTERFACE_RANK_Y		20

	#define INTERFACE_RANK_NO_X			(INTERFACE_RANK_X - 5)
	#define INTERFACE_RANK_NO_Y			INTERFACE_RANK_Y
	#define INTERFACE_RANK_POS_X		(INTERFACE_RANK_X - 4)
	#define INTERFACE_RANK_POS_Y		(INTERFACE_RANK_Y - 11)
	#define INTERFACE_RANK_SLASH_X		(INTERFACE_RANK_X - 1)
	#define INTERFACE_RANK_SLASH_Y		(INTERFACE_RANK_Y + 6)
	#define INTERFACE_RANK_TOTAL_X		(INTERFACE_RANK_X + 11)
	#define INTERFACE_RANK_TOTAL_Y		(INTERFACE_RANK_Y + 6)

	#define LAP_X (m_dispX - 29)
	#define LAP_Y 5

	#define LAP_X_OFFSET1 (-6)
	#define LAP_X_OFFSET2 7

//	#define WANTED_Y_OFFSET 16
	
	#define READY_Y			100	

	#define CUTSCENE_MESSAGE_MAX_HEIGHT		(m_dispX <= m_dispY ? 50 : 35)
	#define CUTSCENE_MESSAGE_BOTTOM_Y		(m_dispY - maxHeight / 2)

	#define NITRO_BAR_LEFT_X			(7)
	#define NITRO_BAR_CENTER_X			(m_dispX / 2 - 40)
	#define NITRO_BAR_Y					(m_dispY - 20)
	
	#define NITRO_BAR_WIDTH				136
	#define NITRO_BAR_HEIGHT			13

	#define ZONE_NAME_X			(m_dispX >> 1)
	#define ZONE_NAME_Y			67
	#define ZONE_NAME_TEXT_Y	(ZONE_NAME_Y)
	

	//moved to each resolution
	//#define ZONE_NAME_X			(m_dispX >> 1)
	//#define ZONE_NAME_Y			52
	//#define ZONE_NAME_TEXT_Y	(ZONE_NAME_Y + 2)

	#define INTERFACE_WANTED_POS_X		((m_dispX - 105) / 2)
	#define INTERFACE_WANTED_POS_Y		3
	#define INTERFACE_WANTED_POS_W		102
	#define INTERFACE_WANTED_POS_H		20

#ifdef TOUCH_INGAME_BUTTON_MENU

	#define INTERFACE_LAP_POS_X			 ((m_dispX >> 1))
	#define INTERFACE_LAP_POS_Y			 40
	
	#define INTERFACE_LAP_NO_X			 (INTERFACE_LAP_POS_X - 5)
	#define INTERFACE_LAP_NO_Y			 INTERFACE_LAP_POS_Y
	#define INTERFACE_LAP_LAP_X			 (INTERFACE_LAP_POS_X - 4)
	#define INTERFACE_LAP_LAP_Y			 (INTERFACE_LAP_POS_Y - 11)
	#define INTERFACE_LAP_SLASH_X		 (INTERFACE_LAP_POS_X - 1)
	#define INTERFACE_LAP_SLASH_Y		 (INTERFACE_LAP_POS_Y + 6)
	#define INTERFACE_LAP_TOTAL_X		 (INTERFACE_LAP_POS_X + 11)
	#define INTERFACE_LAP_TOTAL_Y		 (INTERFACE_LAP_POS_Y + 6)
	
#else // TOUCH_INGAME_BUTTON_MENU
	
	#define INTERFACE_LAP_POS_X			 ((m_dispX >> 1) - 10)
	#define INTERFACE_LAP_POS_Y			 5
//geo
#ifdef R176x208
	#define INTERFACE_LAP_TEXT_POS_Y	 (INTERFACE_LAP_POS_Y + 17)
#else
	#define INTERFACE_LAP_TEXT_POS_Y	 (INTERFACE_LAP_POS_Y + 20)
#endif
	
#endif // TOUCH_INGAME_BUTTON_MENU

//moved for each resolution
//#define NITRO_BAR_Y					(m_dispY - 7)

#define MESSAGE_HUD_MAX_WIDTH					(m_dispX - 6)
#define MESSAGE_HUD_MAX_WIDTH_TYPE_STEERING		(IS_PORTRAIT ? (248) : (386))
#define MESSAGE_HUD_X_TYPE_STEERING				(IS_PORTRAIT ? (124) : (193))
#define MESSAGE_HUD_Y_TYPE_STEERING				(45)

#define BEATEMALL_ICON_X			(24)
#define BEATEMALL_ICON_Y			(MINIMAP_POSY + MINIMAP_SIZEY + 4)//(INTERFACE_LAP_POS_Y + 36)			

// right-top alligned
#define CASH_ATTACK_MONEY_X			(m_dispX - 8)
#define CASH_ATTACK_MONEY_Y			(MINIMAP_POSY + MINIMAP_SIZEY / 2)


#define FONT_POS_P_IMAGE			0
#define FONT_POS_P_YELLOW			1
#define FONT_POS_P_BLUE				2
#define FONT_POS_P_RED				3
#define FONT_POS_P_ORANGE			4

#define REVERSE_TEXT_Y				(MINIMAP_POSY + MINIMAP_SIZEY )

// touch controls
#ifdef USE_TOUCH_SCREEN
// The id's must be bigger than the max number of elements from a menu - fix for #1839588
	#define TOUCH_ZONE_WEEL_ID				100
	#define TOUCH_ZONE_BREAK_ID				101
	#define TOUCH_ZONE_NITRO_ID				102
	#define TOUCH_ZONE_MENU_ID				103
	#define TOUCH_ZONE_CAMERA_ID			104
	#define TOUCH_ZONE_CONTROLS_ID			105
	#define TOUCH_ZONE_CONTINUE				106
	
	#define TOUCH_ZONE_MENU_X 				1
	#define TOUCH_ZONE_MENU_Y 				1
	#define TOUCH_ZONE_MENU_W 				40
	#define TOUCH_ZONE_MENU_H 				40
	
	#define TOUCH_ZONE_CAMERA_W 			50
	#define TOUCH_ZONE_CAMERA_H 			50
	#define TOUCH_ZONE_CAMERA_X 			0
	#define TOUCH_ZONE_CAMERA_Y 			((m_dispY - TOUCH_ZONE_CAMERA_H) / 2)
	
	#define TOUCH_ZONE_CONTROLS_W 			50
	#define TOUCH_ZONE_CONTROLS_H 			40
	#define TOUCH_ZONE_CONTROLS_X 			51
	#define TOUCH_ZONE_CONTROLS_Y 			0

#ifdef TOUCH_CAR_CONTROL_1
	#define CTL1_WEEL_RADIUS				100
	#define CTL1_WEEL_POS_X					(CTL1_WEEL_RADIUS + 5)
	#define CTL1_WEEL_POS_Y					(m_dispY + 10)
	
	#define TOUCH_CTL1_ZONE_WEEL_X 			(CTL1_WEEL_POS_X - CTL1_WEEL_RADIUS)
	#define TOUCH_CTL1_ZONE_WEEL_Y 			(CTL1_WEEL_POS_Y - CTL1_WEEL_RADIUS)
	#define TOUCH_CTL1_ZONE_WEEL_W 			(2 * CTL1_WEEL_RADIUS)
	#define TOUCH_CTL1_ZONE_WEEL_H 			(m_dispY - TOUCH_CTL1_ZONE_WEEL_Y)
	
	#define TOUCH_CTL1_ZONE_NITRO_X 		(m_dispX - 45)
	#define TOUCH_CTL1_ZONE_NITRO_Y 		(m_dispY - 118)
	#define TOUCH_CTL1_ZONE_NITRO_W 		44
	#define TOUCH_CTL1_ZONE_NITRO_H 		44
	
	#define TOUCH_CTL1_ZONE_BREAK_X 		(m_dispX - 113)
	#define TOUCH_CTL1_ZONE_BREAK_Y 		(m_dispY - 78)
	#define TOUCH_CTL1_ZONE_BREAK_W 		44
	#define TOUCH_CTL1_ZONE_BREAK_H 		44
	
	#define CTL1_WEEL_DRIFT_BEGIN			(ONE * 7 / 10)
#endif // TOUCH_CAR_CONTROL_1

#ifdef TOUCH_CAR_CONTROL_2
	#define TOUCH_CTL2_ZONE_WEEL_X 			0
	#define TOUCH_CTL2_ZONE_WEEL_Y 			0
	#define TOUCH_CTL2_ZONE_WEEL_W 			m_dispX
	#define TOUCH_CTL2_ZONE_WEEL_H 			(m_dispY - 160)
	
	#define TOUCH_CTL2_ZONE_NITRO_X 		(m_dispX - 45)
	#define TOUCH_CTL2_ZONE_NITRO_Y 		(m_dispY - 118)
	#define TOUCH_CTL2_ZONE_NITRO_W 		44
	#define TOUCH_CTL2_ZONE_NITRO_H 		44
	
	#define TOUCH_CTL2_ZONE_BREAK_X 		(m_dispX - 113)
	#define TOUCH_CTL2_ZONE_BREAK_Y 		(m_dispY - 78)
	#define TOUCH_CTL2_ZONE_BREAK_W			44
	#define TOUCH_CTL2_ZONE_BREAK_H 		44
	
	#define CTL2_WEEL_TURN_BEGIN			(ONE / 10)
	#define CTL2_WEEL_DRIFT_BEGIN			(ONE * 3 / 10)
#endif // TOUCH_CAR_CONTROL_2

#ifdef TOUCH_CAR_CONTROL_EDGE_TAP
	#define TOUCH_ZONE_WEEL_LEFT_ID						7
	#define TOUCH_ZONE_WEEL_RIGHT_ID					8

	#define TOUCH_CTL_EDGE_ZONE_WEEL_LEFT_X 			0
	#define TOUCH_CTL_EDGE_ZONE_WEEL_LEFT_Y 			(m_dispY / 6)
	#define TOUCH_CTL_EDGE_ZONE_WEEL_LEFT_W 			(m_dispX / 3)
	#define TOUCH_CTL_EDGE_ZONE_WEEL_LEFT_H 			(3 * m_dispY / 5)
	
	#define TOUCH_CTL_EDGE_ZONE_WEEL_RIGHT_X 			(2 * m_dispX / 3)
	#define TOUCH_CTL_EDGE_ZONE_WEEL_RIGHT_Y 			(m_dispY / 6)
	#define TOUCH_CTL_EDGE_ZONE_WEEL_RIGHT_W 			(m_dispX / 3)
	#define TOUCH_CTL_EDGE_ZONE_WEEL_RIGHT_H 			(3 * m_dispY / 5)
	
	#define TOUCH_CTL_EDGE_ZONE_ACCEL_X 				(m_dispX - 45)
	#define TOUCH_CTL_EDGE_ZONE_ACCEL_Y 				(m_dispY - 118)
	#define TOUCH_CTL_EDGE_ZONE_ACCEL_W 				44
	#define TOUCH_CTL_EDGE_ZONE_ACCEL_H 				44
	
	#define TOUCH_CTL_EDGE_ZONE_BREAK_X 				(m_dispX - 113)
	#define TOUCH_CTL_EDGE_ZONE_BREAK_Y 				(m_dispY - 78)
	#define TOUCH_CTL_EDGE_ZONE_BREAK_W 				44
	#define TOUCH_CTL_EDGE_ZONE_BREAK_H 				44
#endif // TOUCH_CAR_CONTROL_EDGE_TAP

#ifdef CAR_CONTROL_ACCELEROMETER
	#define TOUCH_CTL_ACCEL_ZONE_ACCEL_X 				(m_dispX - 45)
	#define TOUCH_CTL_ACCEL_ZONE_ACCEL_Y 				(m_dispY - 118)
	#define TOUCH_CTL_ACCEL_ZONE_ACCEL_W 				44
	#define TOUCH_CTL_ACCEL_ZONE_ACCEL_H 				44
	
	#define TOUCH_CTL_ACCEL_ZONE_BREAK_X 				(m_dispX - 113)
	#define TOUCH_CTL_ACCEL_ZONE_BREAK_Y 				(m_dispY - 78)
	#define TOUCH_CTL_ACCEL_ZONE_BREAK_W 				44
	#define TOUCH_CTL_ACCEL_ZONE_BREAK_H 				44
#endif // CAR_CONTROL_ACCELEROMETER

#endif

#ifdef CAR_CONTROL_ACCELEROMETER
	#include "IphoneUtil.h"

	#define CAR_ACCEL_PHONE_MOVE_SPEED_TRIGER	(ONE * 3)
//	#define CAR_BREAK_PHONE_POS_TRIGER			(ONE * 3 / 10)
//	#define CAR_DRIFT_PHONE_MOVE_SPEED_TRIGER	(ONE * 3 / 2)
	#define CAR_DRIFT_PHONE_ANGLE_TRIGER		(ONE / 4)
	#define CAR_TURN_PHONE_ANGLE_TRIGER			(ONE / 10)
	#define CAR_ACCEL_DEAD_DIR_ANGLE			(ONE / 45)
	#define CAR_ACCEL_MAX_DIR_ANGLE				(ONE / 4)
#endif

// tutorial
#define TUT_MSG_TOP_POS_X					(m_dispX / 2)
#define TUT_MSG_TOP_POS_Y					(m_dispY / 8)

#define TUT_MSG_WIDTH						(m_dispX - 20)

#define TUT_CONTINUE_BOTTOM_POS_X			(m_dispX / 2)
#define TUT_CONTINUE_BOTTOM_POS_Y			(m_dispY - 20)

#endif	// PLAYING_GAME__DEFINES__H__INCLUDED__
