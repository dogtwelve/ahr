#include "A4_3d_platform_def.h"

#include "HighGear.h"

#include "GenDef.h"
#include "time.h"

#include "lib3D.h"
#include "File.h"
#include "Intl.h"

#include "sprites.h"


#include "ArchivedFileManager.h"

#include "lib2d/AuroraSprite.h"
#include "lib2d/FontWrapper.h"

#include "config.h"

#ifdef CHECK_MEMORY_LEAKS
#include "MemoryManager.h"
#endif
#include "Sound/SoundManager.h"



/// NOTE: Next file was generated from 'MakeSounds.bat', which is in data directory.
#include "SoundsTable.h"


#ifdef USE_IPHONE_INTRO_VIDEO
	#include "IphoneUtil.h"
	#include "iPhone/Sound/SoundEngine.h"
#endif


#ifdef HAS_MULTIPLAYER
#include "MultiPlayer/Comms.h"

#ifdef HAS_BLUETOOTH_NGAGE
	#include "MultiPlayer/BluetoothNgage.h"
#endif // HAS_BLUETOOTH_NGAGE

#endif // HAS_MULTIPLAYER


#ifdef IPHONE
extern void GetDeviceLanguage(char *lang);
#endif

#include "ScreenBufferWrapper.h"

extern bool g_bSkipRendering;

#if (defined(WIN32) || defined(__WINS__))  && !defined(__BREW__)
# define for if (false) ; else for
#endif

#define GAMELOFT_LOGO_BACKGROUND_COLOR	0xFFFF



CHighGear::CHighGear(CGapi& gapi) :
	    m_gapi(gapi),

    m_lib3D(0),
	m_lib2D(0),


	m_isInPhoneCall(false),
	m_bStartUpOrientationOverride(0)

{

#ifdef AUTODETECT_PHONE_RESOLUTION
	m_dispX = initialDisplayOrientationX;
	m_dispY = initialDisplayOrientationY;
#else
	m_dispX = INITIAL_DISP_X;
	m_dispY = INITIAL_DISP_Y;
#endif



	m_lib2D = NEW CLib2D(gapi.ScreenPtr, m_dispX, m_dispY, *m_lib3D);

	m_screenImage2D = new Image(m_dispX, m_dispY, gapi.ScreenPtr);

	
#ifdef USE_TOUCH_SCREEN
	touchZones = CTouchZones::GetInstance();
#endif // USE_TOUCH_SCREEN
	

#ifdef USE_BACK_LIGHT
	m_pLight = NULL;
	m_bChargerConected = false;
#endif
	
	game_state = gs_test_loading;
}


//BBucur.15.09.2004. Commented parts for debug. Uncomment all.
CHighGear::~CHighGear()
{
	MM_DELETE m_lib3D;
	MM_DELETE m_lib2D;
	MM_DELETE m_screenImage2D;


#ifdef USE_BACK_LIGHT
	SAFE_DELETE(m_pLight);
#endif
}

// Returns true when the loading is done
bool CHighGear::InitHighGear(int step)
{
	switch (step)
	{
	case 0:
		CArchivedFileManager::GetInstance()->CreateAllFileMappingTable();
		break;

	case 1:
		// Lib3D
		m_lib3D = NEW Lib3D::CLib3D;
		m_lib3D->Init();// init renderer matrix stack
		m_lib2D->SetLib3D(m_lib3D);

		m_lib3D->m_board3d->m_screen = m_lib2D->GetDestPtr();

		m_lib3D->m_screenImage3D = m_screenImage2D;
		m_screenImage3D = m_lib3D->m_screenImage3D;


		break;

	case 2:

		break;

	case 3:
		{
			/// Turn on backlight
			Gapi().TurnOnBackLight();

	//		LoadSplashImageBuffers();
		}
		break;

	case 4:

		break;


	case 5:


	case 6:

		return true;
	}


	return false;
}

#ifdef IPHONE
extern "C" void setStatusBarOrientation(int orient);
#endif

bool CHighGear::InitDisplayOrientation(int orientation)
{
	debug_out("orientation %d %d\n",orientation,Gapi().GetDisplayOrientation());

	if (orientation == Gapi().GetDisplayOrientation())
	{
		return true;
	}

//SEFU ADD
#ifdef ORINETATION_CHANGE_KEYS
	if(Gapi().m_orientationOptionsInMenus)
	{
		switch(orientation)
		{
			case ORIENTATION_PORTRAIT:
				SetKeyBoardConfig(0);
				break;
			case ORIENTATION_LANDSCAPE_90:
				SetKeyBoardConfig(1);
				break;
			case ORIENTATION_LANDSCAPE_270:
				SetKeyBoardConfig(2);
				break;
		}
	}
#endif

	if(orientation == INITIAL_ORIENTATION)
	{
#ifdef AUTODETECT_PHONE_RESOLUTION
		m_dispX = initialDisplayOrientationX;
		m_dispY = initialDisplayOrientationY;
#else
		m_dispX = INITIAL_DISP_X;
		m_dispY = INITIAL_DISP_Y;
#endif
	}
	else
	{
#ifdef AUTODETECT_PHONE_RESOLUTION
		m_dispX = initialDisplayOrientationY;
		m_dispY = initialDisplayOrientationX;
#else
		m_dispX = INITIAL_DISP_Y;
		m_dispY = INITIAL_DISP_X;
#endif
	}

	Gapi().mCurrentOrientation = orientation;


	if (m_lib3D)
	{
		// Recalc Fov, yeah it's stupid way, but it checks if the value is different
		int fov = m_lib3D->GetFoV();
		m_lib3D->SetFov(fov+1);
		m_lib3D->SetFov(fov);

		if(m_lib3D->m_board3d)
		{
			//m_lib3D->m_board3d->recalcScreenPtr();
#if USE_STENCIL_BUFFER
			m_lib3D->m_board3d->ClearStencil(true);
#endif
		}

		m_lib3D->m_screenImage3D->changeSize(m_dispX, m_dispY);
	}


	m_screenImage2D->changeSize(m_dispX, m_dispY);

	if (m_lib2D)
	{
		m_lib2D->ResetClip();
		m_lib2D->SetDestPtr(m_lib2D->GetDestPtr(), m_dispX, m_dispY);
		m_lib2D->ResetClip();
	}

#ifndef USE_OGL
//	if (m_PlayingGame && m_PlayingGame->m_Map)
//	{
//		CCar* playerCar = m_PlayingGame->GetPlayerCar();
//
//		if (playerCar)
//			playerCar->recalculateEnvMap();
////SEFU 
//		if (game_state == gs_play && !Gapi().m_orientationOptionsInMenus)
//		{
//			m_PlayingGame->RecreateInGameMenu();
//		}
//		if (game_state == gs_ingame_menu)
//		{
//			//LAngelov: we must recreate InGame Menu
//			m_PlayingGame->RecreateInGameMenu();
//		}
//	}
#endif // USE_OGL



// rax - moved above, needed for IGM menu arrow (its pos is changed based on m_Profile.orientation)
//	Gapi().mCurrentOrientation = orientation;
//	m_Profile.orientation = orientation;


	debug_out("IDO:2\n");
	return true;
}

// global inits
int CHighGear::GameInit(void)
{
    return 1;
}


/////////////////////////////////////////////////////////////////////////////////
extern void OGLRefresh3D();



void CHighGear::GameLoop(void)
{

	int m_dispX = 320, m_dispY = 480;
	int alpha = 255;

	switch( game_state )
	{
		case gs_test_loading:
			InitHighGear(0);
			InitHighGear(1);
			InitHighGear(2);
			InitHighGear(3);
			

			g_bRefreshScreenBuffer = true;
			
			m_logoSprite = NEW CSprite("textures\\gameloft.bsp");
			//m_logoSprite = NEW CSprite("main.bar\\gameloft.bsp");
			
			game_state = gs_test_view;
			
			break;
		
		case gs_test_view:
//			GetLib2D().SetClip(0, 0, 320, 240);
//			GetLib2D().DrawRect(0, 0, 320, 480, 0xffff);
			
//			g_lib3DGL->fillRect(0,0,320,480, 0xffff0000);
//			g_lib3DGL->Flush2D();
			

#ifdef USE_TOUCH_SCREEN
			touchZones->ClearZones();
#endif // USE_TOUCH_SCREEN
			
			
			//m_logoSprite->DrawFrame(GetLib2D(), m_dispX >> 1, m_dispY >> 1, GAMELOFT_F_PORTRAIT);
			GetLib2D().DrawRect(0, 0, m_dispX, m_dispY, GAMELOFT_LOGO_BACKGROUND_COLOR);
			

//			GetLib2D().setColor(0x84000000);
			
			alpha = abs(15 - m_FrameCounter % 255);
			m_logoSprite->SetGlobalAlpha(alpha);
			GetLib2D().setColor(0xffffff | (alpha<<24) );
			m_logoSprite->DrawFrame(GetLib2D(), m_dispX >> 1, m_dispY >> 1, IS_PORTRAIT ? GAMELOFT_F_PORTRAIT : GAMELOFT_F_LANDSCAPE);
			
//			m_lib2D->DrawRect(0,0,320,480, 0xffff0000);
//			g_lib3DGL->Flush2D();
			
#ifdef USE_TOUCH_SCREEN
			touchZones->AddZone(0, 0, 0, m_dispX, m_dispY);
#endif // USE_TOUCH_SCREEN
			Gapi().m_Keypad.Keypad_UpdateState(kKeypad_Update_Smart);
			
			if (Gapi().m_Keypad.Keypad_HasAnyKeyBeenPressed() 
#ifdef USE_TOUCH_SCREEN
				|| touchZones->WasZoneActivated(0)
#endif // USE_TOUCH_SCREEN
				)
			{
				game_state = gs_test_view2;
			}
			
			break;
			
		case gs_test_view2:
		
			GetLib2D().DrawRect(0, 0, 240, 320, 0x00);
			
//			int alpha = abs(15 - m_FrameCounter % 255);
//			m_logoSprite->SetGlobalAlpha(alpha);
//			GetLib2D().setColor(0xffffff | (alpha<<24) );
			m_logoSprite->DrawFrame(GetLib2D(), m_dispX >> 1, m_dispY >> 1, IS_PORTRAIT ? GAMELOFT_F_PORTRAIT : GAMELOFT_F_LANDSCAPE);
			
			break;
	}
	
	m_FrameCounter++;

#ifdef USE_TOUCH_SCREEN
//	if (game_state != gs_play
//		
//		&& game_state != gs_suspended)
//	{
		touchZones->Update();
	#ifdef DRAW_TOUCH_ZONES
		touchZones->DrawZones(GetLib2D());
	#endif // DRAW_TOUCH_ZONES
//	}
#endif // USE_TOUCH_SCREEN


}




#ifdef USE_TOUCH_SCREEN
void CHighGear::ZonePressed(short zoneId)
{
	return;
}

void CHighGear::ZoneReleased(short zoneId)
{
	return;
}

void CHighGear::ZoneActivated(short zoneId)
{
	return;
}

void CHighGear::ZoneMove(short zoneId, int x, int y)
{
	return;
}
#endif // USE_TOUCH_SCREEN

