#ifndef DEFINE_IPHONE__H__INCLUDED__
#define DEFINE_IPHONE__H__INCLUDED__

//Resolution
#define R320x480

// ASprite defines
#define USE_SINGLE_IMAGE


#endif	// ! DEFINE_IPHONE__H__INCLUDED__
