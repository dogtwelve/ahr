//
// This file was generated using GenerateVersionH.bat
//
#ifndef __GL_VERSION_H_INCLUDED__
#define __GL_VERSION_H_INCLUDED__
//
#define VERSION_TEXT "0.0.1"
#define VERSION_COMPLETE_TEXT "Asphalt4 Version " VERSION_TEXT
#define VERSION_MAJOR (0) 
#define VERSION_MINOR (0) 
#define VERSION_BUILD (1) 
#define VERSION_ID  ((VERSION_MAJOR<<24)+(VERSION_MINOR<<16)+VERSION_BUILD) 
//
#endif //__GL_VERSION_H_INCLUDED__
//
